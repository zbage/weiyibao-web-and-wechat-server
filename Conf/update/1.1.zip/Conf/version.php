<?php
return array (
  'ver' => '1.1',
);
?>